let lattext = document.getElementById("lat");
let longtext = document.getElementById("long");
let nearestDistance = document.getElementById("dist");
let userLocationMarker;
let action = document.getElementById("action");
let playedPoints = new Set();


let polylineCoords = [
  [41.92809632, 42.0306927],
  [41.92760941, 42.03096092],
  [41.92524266, 42.02552676],
  [41.92302749, 42.01927722],
  [41.92245673, 42.02060759],
  [41.92022949, 42.02306986],
  [41.91965072, 42.02350438],
  [41.91962677, 42.02216327],
  [41.9189003, 42.01848328],
  [41.91902004, 42.01603711],
  [41.91897614, 42.01449215],
  [41.9194232, 42.01378405],
  [41.91995407, 42.01336026],
  [41.91960681, 42.00984657],
  [41.91934736, 42.00903118],
  [41.91977046, 42.00662792],
  [41.92019357, 42.00616658],
  [41.92114754, 42.00589836],
  [41.92161853, 42.00626314],
  [41.92179415, 42.00598419],
  [41.92159857, 42.0056355],
  [41.92118745, 42.00541019],
  [41.92113556, 42.00242758],
  [41.91776667, 42.00235784],
  [41.91739544, 42.00105429],
  [41.91720783, 42.00099528],
  [41.91662503, 42.00176775],
  [41.91653322, 42.00279236],
  [41.91679668, 42.00300694],
  [41.91724775, 42.00249195],
  [41.91997802, 42.00261533],
  [41.92103977, 42.00254023],
  [41.92113157, 42.00567842],
  [41.92149878, 42.0062685],
  [41.9222372, 42.00586081],
  [41.92254454, 42.00587153],
  [41.92227711, 42.00765789],
  [41.92382975, 42.00748622],
  [41.92364615, 42.00557649],
  [41.92312329, 42.00560331],
  [41.92316719, 42.00200915],
  [41.92353439, 42.00186431],
  [41.92423686, 42.00107038],
  [41.92535441, 42.0024544],
  [41.92543025, 42.00330734],
  [41.92662361, 42.0031625],
  [41.92717438, 42.00473428],
  [41.92724622, 42.00526536],
  [41.92547814, 42.00540483],
  [41.92390559, 42.00551748],
  [41.9214469, 42.00573742],
  [41.92138303, 42.00593054],
  [41.92146685, 42.00655818],
  [41.92080427, 42.00893998],
  [41.92140299, 42.01248586],
  [41.92252059, 42.01198161],
  [41.92404129, 42.01547384],
  [41.92519077, 42.01906264],
  [41.92315123, 42.01985121],
  [41.92416502, 42.02294111],
  [41.92529055, 42.02575743],
  [41.92756551, 42.03107893],
  [41.92802847, 42.03081608]
];
let checkpoints = [
  [41.9251389, 42.0127594],
  [41.9252546, 42.0130759],
  [41.9253624, 42.0133442],
  [41.9254781, 42.0137572],
  [41.9253065, 42.0139664],
  [41.9250271, 42.0141596],
  [41.9248715, 42.0142454],
  [41.9246480, 42.0143956],
  [41.9244404, 42.0145619],
  [41.9242329, 42.0147282]
];





// Define the audio files for each option
const audioFiles = {
  "100left": "audio/100left.mp3",
  "100right": "audio/100right.mp3",
  "left": "audio/left.mp3",
  "right": "audio/right.mp3",
  "start": "audio/start.mp3"
};



// Define the options list
const options = ["start", "right", "right", "left", "left","start", "100right", "100left", "right", "left"]; // Example options list




let sumLat = polylineCoords.reduce((acc, val) => acc + val[0], 0);
let sumLng = polylineCoords.reduce((acc, val) => acc + val[1], 0);

let avgLat = sumLat / polylineCoords.length;
let avgLng = sumLng / polylineCoords.length;

let map = L.map('map').setView([avgLat, avgLng], 16.3);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
}).addTo(map);

let checkpointMarkers = []; // Initialize an empty array to store checkpoint markers

polylineCoords.forEach((coord, index) => {
    let color = 'cyan';
    if (index === 0) color = 'red'; // Start point
    else if (index === polylineCoords.length - 1) color = 'black'; // End point

    let circleMarker = L.circleMarker(coord, {
        color: color,
        fillColor: 'blue',
        fillOpacity: 1,
        radius:5
    }).addTo(map);

    //animateBreathing(circleMarker); // Apply breathing animation to each marker

    // Store the marker and its index or any other relevant info
    checkpointMarkers.push({
        marker: circleMarker,
        index: index,
        coordinates: coord,
        description: `Checkpoint ${index + 1}`
    });
});

// Example of how to use the list
// Focus the map on the first checkpoint marker when a certain event occurs
//console.log("cc ", checkpointMarkers[0].coordinates);



let polyline = L.polyline(polylineCoords, {color: 'blue', weight: 5, dashArray: '12, 12'}).addTo(map);




// Function to calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Radius of the Earth in meters
  const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in meters
  return distance;
}


function playAudio(audioKey) {
  // Ensure the audio key is valid and the file exists
  if (audioFiles.hasOwnProperty(audioKey)) {
      let audio = new Audio(audioFiles[audioKey]);
      audio.play();
  } else {
      console.error("Audio file not found for key:", audioKey);
  }
}


// Define a variable to track the index of the current checkpoint
let currentCheckpointIndex = 0;




// Start watching the user's location with higher accuracy and faster updates
navigator.geolocation.watchPosition((position) => {
    let lat = position.coords.latitude;
    let lng = position.coords.longitude;
    updateUserLocation(lat, lng); // Update the location on the map
    

    // Get the current checkpoint and the next checkpoint
    let currentCheckpoint = checkpoints[currentCheckpointIndex];
    let nextCheckpoint = checkpoints[currentCheckpointIndex + 1];

   // Calculate the distance from the current location to the next checkpoint
let distanceToNextCheckpoint;
if (nextCheckpoint) {
    distanceToNextCheckpoint = calculateDistance(lat, lng, nextCheckpoint[0], nextCheckpoint[1]);
} else {
    // Handle the case where there is no next checkpoint
    console.log("You have reached the end of the route.");
    return; // Exit the function or add further logic as needed
}

// If the distance to the next checkpoint is less than a threshold (e.g., 0.001), 
// consider the current checkpoint passed and move to the next one
if (distanceToNextCheckpoint < 20) {
    const currentOption = options[currentCheckpointIndex];
    console.log(`CCCCCurent option ${currentOption}`);
        if (!playedPoints.has(currentOption)) {
            playAudio(currentOption);  // Play the audio based on the current option
            playedPoints.add(currentOption);
        }
    currentCheckpointIndex++; // Move to the next checkpoint
    console.log(`You have passed checkpoint ${currentCheckpointIndex}`);
}


lattext.innerHTML = `Checkpoint index: ${currentCheckpointIndex}`; // Update the checkpoint index text
longtext.innerHTML = `Distance to next checkpoint: ${distanceToNextCheckpoint.toFixed(0)} meters`; // Update the distance text


    // Print the real-time distance from the current location to the next checkpoint
    console.log(`Real-time distance to next checkpoint: ${distanceToNextCheckpoint} meters`);
}, (err) => {
    console.error("Error getting the position - ", err);
}, {
    enableHighAccuracy: true, // Enable high accuracy mode for better accuracy
    maximumAge: 100, // Reduce the maximum age to get fresher location updates
    timeout: 5000 // Reduce the timeout to get faster updates
});

// Add checkpoint markers to the map
checkpoints.forEach((checkpoint, index) => {
  L.marker(checkpoint).addTo(map).bindPopup(`Checkpoint ${index + 1}`); // Add a marker for each checkpoint
});



// =====================================================================================
// Function to update the user's location marker on the map
function updateUserLocation(lat, lng) {
  // Remove the previous user location marker if it exists
  if (userLocationMarker) {
      map.removeLayer(userLocationMarker);
  }

  // Define custom marker icon options
  var customIcon = L.icon({
    iconUrl: 'icons/placeholder.png', // URL to the custom icon image
    iconSize: [32, 32], // Size of the icon
    iconAnchor: [16, 32], // Point of the icon which will correspond to marker's location
    popupAnchor: [0, -32] // Point from which the popup should open relative to the iconAnchor
  });

  // Create a new marker for the user's location with custom icon
  userLocationMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
}




